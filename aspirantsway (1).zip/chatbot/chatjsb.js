function emptyButton(){
  buttonSendText("empty")
}
function prelimsButton() {
  buttonSendText("prelims")
}
function mainsButton() {
  buttonSendText("mains")
}
function optionalButton() {
  buttonSendText("optional")
}
function essayButton() {
  buttonSendText("essay")
}
function languagePaperButton() {
  buttonSendText("language papers")
}
function interviewButton() {
  buttonSendText("hello")
}
function firstReadingButton() {
  buttonSendText("first reading")
}
function notesButton() {
  buttonSendText("notes")
}
function revisionButton() {
  buttonSendText("hello")
}
function booklistButton() {
  buttonSendText("booklist")
}
function startingButton() {
  buttonSendText("starting")
}
function analysisButton() {
  buttonSendText("hello")
}
function lifeProblemsButton() {
  buttonSendText("hello")
}
function eNotesButton() {
  buttonSendText("hello")
}
function illnessButton() {
  buttonSendText("hello")
}
function strategyButton() {
  buttonSendText("strategy")
}
function selfStudyButton() {
  buttonSendText("hello")
}
function mediumButton() {
  buttonSendText("hello")
}
function upsccseMeaningButton() {
  buttonSendText("upsc cse")
}
function fullFormsButton() {
  buttonSendText("upsc related full forms")
}
function collectorButton() {
  buttonSendText("कलेक्टर कैसे बने?")
}
function moremainButton() {
  buttonSendText("more buttons")
}
function mainManuButton() {
  buttonSendText("main manu")
}
function upscFFButton(){
  buttonSendText("upsc full form")
}
function cseFFButton(){
  buttonSendText("cse full form")
}
function iasFFButton(){
  buttonSendText("ias full form")
}
function ipsFFButton(){
  buttonSendText("ips full form")
}
function ifsFFButton(){
  buttonSendText("ifs full form")
}
function irsFFButton(){
  buttonSendText("irs full form")
}
